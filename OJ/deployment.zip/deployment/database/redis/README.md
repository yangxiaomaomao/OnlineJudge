# redis directory

Hold directory for redis.