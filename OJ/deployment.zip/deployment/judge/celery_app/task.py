'''
Author: your name
Date: 2021-07-29 17:06:39
LastEditTime: 2021-08-12 20:43:22
LastEditors: Please set LastEditors
Description: In User Settings Edit
FilePath: \yjb\celery_app\task.py
'''

from celery_app import app
import os
import time

@app.task
#TODO add parameter
def sendCmdToWorker(fileId,expId,userId,filePath):
    #TODO scp file from master to worker
    if not os.path.exists("./FIXED/test/"):
        os.system("mkdir ./FIXED/test/")
    os.system("scp -r localhost:{filePath} ./FIXED/test/".format(filePath = filePath))
    #TODO avoid time too long
    time.sleep(0.5)
    #TODO solve the sudo and passwd issues
    os.system("cd FIXED && sudo python main.py {fileId} {expId} {userId} {filePath}".format(fileId = fileId,expId = expId,userId = userId,filePath = filePath))
    #os.system("cd FIXED && sudo python main.py")
    with open("./FIXED/result.json","r") as f:
        retJson = f.read()
    os.system("rm -f ./FIXED/result.json")
    os.system("rm -rf ./FIXED/test/")
    return retJson