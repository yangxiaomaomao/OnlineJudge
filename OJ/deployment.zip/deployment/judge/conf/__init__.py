'''
Author: your name
Date: 2021-08-12 22:10:15
LastEditTime: 2021-08-12 22:10:16
LastEditors: Please set LastEditors
Description: In User Settings Edit
FilePath: \sunConnectyy\conf\__init__.py
'''
