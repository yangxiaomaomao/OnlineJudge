# Logs directory

Logs of nginx for debug.