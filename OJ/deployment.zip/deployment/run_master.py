'''
Author: your name
Date: 2021-09-30 12:38:29
LastEditTime: 2021-10-01 12:46:10
LastEditors: Jingbin Yang
Description: In User Settings Edit
FilePath: \deployment\start_master.py
'''

import subprocess

start_nginx    = "sudo systemctl restart nginx"
start_judger   = "java -jar springBoot/OnlineJudge.jar"
start_database = "cd database && sudo docker-compose up -d"
start_master   = "cd judge && python master.py"

def main():
    subprocess.Popen(start_nginx,shell=True)
    subprocess.Popen(start_judger,shell=True)
    subprocess.Popen(start_database,shell=True)
    subprocess.Popen(start_master,shell=True)

if __name__ == "__main__":
    main()

