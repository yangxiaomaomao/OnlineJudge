###
 # @Descripttion: Online Judge
 # @version: ^_^
 # @Author: Jingbin Yang
 # @Date: 2021-10-01 12:37:31
 # @LastEditors: Jingbin Yang
 # @LastEditTime: 2021-10-01 13:26:05
### 
chmod 777 *.sh
./setup_master.sh
python3 run_master.py