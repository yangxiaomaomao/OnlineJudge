
###
 # @Descripttion: Online Judge
 # @version: ^_^
 # @Author: Jingbin Yang
 # @Date: 2021-09-30 15:25:52
 # @LastEditors: Jingbin Yang
 # @LastEditTime: 2021-10-01 12:39:13
### 
chmod 777 *.sh
./setup_worker.sh
./run_worker.sh
