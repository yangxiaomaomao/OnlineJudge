#include "tcp_sock.h"

#include "log.h" 

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h> 

// tcp server application, listens to port (specified by arg) and serves only one
// connection request
void *tcp_server(void *arg)
{
	// ./tcp_stack server 10001(my port for sock) 
	u16 port = *(u16 *)arg;
	struct tcp_sock *tsk = alloc_tcp_sock();

	struct sock_addr addr;
	addr.ip = htonl(0);
	addr.port = port;
	if (tcp_sock_bind(tsk, &addr) < 0) {
		log(ERROR, "tcp_sock bind to port %hu failed", ntohs(port));
		exit(1);
	}

	if (tcp_sock_listen(tsk, 3) < 0) {
		log(ERROR, "tcp_sock listen failed");
		exit(1);
	}

	log(DEBUG, "listen to port %hu.", ntohs(port));

	struct tcp_sock *csk = tcp_sock_accept(tsk);

	log(DEBUG, "accept a connection.");

	/* lab15-1 server recieves data and echoes back */
	/*char rbuf[1001];
	char wbuf[1024];
	int rlen = 0;
	while (1) {
		rlen = tcp_sock_read(csk, rbuf, 1000);
		if (rlen == 0) {
			log(DEBUG, "tcp_sock_read return 0, finish transmission.");
			break;
		} 
		else if (rlen > 0) {
			rbuf[rlen] = '\0';
			sprintf(wbuf, "server echoes: %s", rbuf);
			if (tcp_sock_write(csk, wbuf, strlen(wbuf)) < 0) {
				log(DEBUG, "tcp_sock_write return negative value, something goes wrong.");
				exit(1);
			}
		}
		else {
			log(DEBUG, "tcp_sock_read return negative value, something goes wrong.");
			exit(1);
		}
	}*/
	/* lab15-2 server recieves data and stores in server-output.dat */
	char rbuf[1024];
	int rlen = 0;
	FILE *fp = NULL;
	fp = fopen("server-output.dat","w+");
	while (1)
	{
		rlen = tcp_sock_read(csk, rbuf, 1024);
		if (rlen == 0) {
			log(DEBUG, "tcp_sock_read return 0, finish transmission.");
			break;
		} 
		else if (rlen > 0) {
			printf("server write: %d bytes -> server-output.dat\n",rlen);
			size_t wcount = fwrite(rbuf,1,rlen,fp);
			if (wcount < 1024){
				fclose(fp);
				break;
			}
		}
		else {
			log(DEBUG, "tcp_sock_read return negative value, something goes wrong.");
			exit(1);
		}
	}

	log(DEBUG, "close this connection.");

	tcp_sock_close(csk);
	
	return NULL;
}

// tcp client application, connects to server (ip:port specified by arg), each
// time sends one bulk of data and receives one bulk of data 
void *tcp_client(void *arg)
{
	// ./tcp_stack client 10.0.0.1(dip) 10001(dport)
	struct sock_addr *skaddr = arg;

	struct tcp_sock *tsk = alloc_tcp_sock();

	if (tcp_sock_connect(tsk, skaddr) < 0) {
		log(ERROR, "tcp_sock connect to server ("IP_FMT":%hu)failed.", \
				NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));
		exit(1);
	}

	/* lab15-1 client sends data to server and prints echo-back data */
	/*char *data = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	int dlen = strlen(data);
	char *wbuf = malloc(dlen+1);
	char rbuf[1001];
	int rlen = 0;

	int n = 10;
	for (int i = 0; i < n; i++) {
		memcpy(wbuf, data+i, dlen-i);
		if (i > 0) memcpy(wbuf+(dlen-i), data, i);

		if (tcp_sock_write(tsk, wbuf, dlen) < 0)
			break;

		rlen = tcp_sock_read(tsk, rbuf, 1000);
		if (rlen == 0) {
			log(DEBUG, "tcp_sock_read return 0, finish transmission.");
			break;
		}
		else if (rlen > 0) {
			rbuf[rlen] = '\0';
			fprintf(stdout, "%s\n", rbuf);
		}
		else {
			log(DEBUG, "tcp_sock_read return negative value, something goes wrong.");
			exit(1);
		}
		sleep(1);
	}*/

	/* lab15-2 client sends file client-input.dat to server */
	FILE *fp = NULL;
	fp = fopen("client-input.dat","r");
	char *wbuf = malloc(1024);
	char c;
	int file_end = 0;
	while (!file_end){
		int i;
		for (i = 0; i < 1024; i++){
			c=fgetc(fp);
			if (c != EOF){
				wbuf[i] = c;
			}else{
				file_end = 1;
				break;
			}
		}
		if (tcp_sock_write(tsk, wbuf, i) < 0)
			break;

		sleep(1);
	}

	tcp_sock_close(tsk);

	free(wbuf);

	return NULL;
}
