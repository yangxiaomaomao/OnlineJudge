#include "tcp.h"
#include "tcp_sock.h"
#include "tcp_timer.h"

#include "log.h"
#include "ring_buffer.h"

#include <stdlib.h>
// update the snd_wnd of tcp_sock
//
// if the snd_wnd before updating is zero, notify tcp_sock_send (wait_send)
static inline void tcp_update_window(struct tcp_sock *tsk, struct tcp_cb *cb)
{
	u16 old_snd_wnd = tsk->snd_wnd;
	tsk->snd_wnd = cb->rwnd;
	if (old_snd_wnd == 0)
		wake_up(tsk->wait_send);
}

// update the snd_wnd safely: cb->ack should be between snd_una and snd_nxt
static inline void tcp_update_window_safe(struct tcp_sock *tsk, struct tcp_cb *cb)
{
	if (less_or_equal_32b(tsk->snd_una, cb->ack) && less_or_equal_32b(cb->ack, tsk->snd_nxt))
		tcp_update_window(tsk, cb);
}

#ifndef max
#	define max(x,y) ((x)>(y) ? (x) : (y))
#endif

// check whether the sequence number of the incoming packet is in the receiving
// window
static inline int is_tcp_seq_valid(struct tcp_sock *tsk, struct tcp_cb *cb)
{
	u32 rcv_end = tsk->rcv_nxt + max(tsk->rcv_wnd, 1);
	if (less_than_32b(cb->seq, rcv_end) && less_or_equal_32b(tsk->rcv_nxt, cb->seq_end)) {
		return 1;
	}
	else {
		log(ERROR, "received packet with invalid seq, drop it.");
		return 0;
	}
} 
 
/* lab15; lab16*/
void process_recv_data(struct tcp_sock *tsk, struct tcp_cb *cb) {
	if (tsk->rcv_nxt == cb->seq) // if coming data seq is constant, put in ring buffer for app_read
	{
		while (ring_buffer_full(tsk->rcv_buf)) {
			sleep_on(tsk->wait_recv);
		}
		pthread_mutex_lock(&tsk->rcv_buf->lock);
		write_ring_buffer(tsk->rcv_buf, cb->payload, cb->pl_len);
		pthread_mutex_unlock(&tsk->rcv_buf->lock);
		wake_up(tsk->wait_recv);   // wake up for empty sleep in tcp_sock_read
		tsk->rcv_nxt = cb->seq + cb->pl_len;
		tsk->snd_una = cb->ack;
	}else
	{ // if not constant, put receive data in rcv_ofo_buf
		tcp_insert_rcv_ofo_buf(&tsk->rcv_ofo_buf, cb);
	}

	// check if data now is constant, move from from rcv_ofo_buf to rcv_buf
	tcp_check_ofo_buf_to_ring_buf(tsk);
}

/* lab13 ; lab15 ; lab16 */
// Process the incoming packet according to TCP state machine. 
// tsk:the local tcp_sock; cb: info from packet
// lab16: if receive ACK, remove acked packet from send_buf, reset/close retrans_timer, update ring/ofo buffer
void tcp_process(struct tcp_sock *tsk, struct tcp_cb *cb, char *packet)
{
	//fprintf(stdout, "TODO: implement %s please.\n", __FUNCTION__);
	// if tcp_hdr->flag = TCP_RST, end the connection(close the tcp sock)
	if (cb->flags & TCP_RST){
		tcp_sock_close(tsk);
		return;
	}
	if (cb->flags & TCP_ACK){ // lab16 update snd_buf and retrans_timer
		tcp_remove_acked_send_buffer(tsk, cb->ack);
		tcp_update_retrans_timer(tsk);
	}
	

	switch (tsk->state) {
		case TCP_LISTEN:  // when a passively opened tcp sock receives a SYN packet
			if (cb->flags & TCP_SYN) { // malloc a child tcp sock for incoming connection, send ACK/SYN packet back
				tcp_set_state(tsk, TCP_SYN_RECV);
				struct tcp_sock *child_sock = alloc_tcp_child_sock(tsk, cb);
				tcp_send_control_packet(child_sock, TCP_ACK|TCP_SYN);
			}
			break;
		case TCP_SYN_SENT: // when an actively sleep sock receives a ACK|SYN packet
			if((cb->flags & (TCP_ACK|TCP_SYN)) == (TCP_ACK|TCP_SYN)) { // wake up and send ACK packet back, finish connection create 
				wake_up(tsk->wait_connect);
				tcp_set_state(tsk, TCP_ESTABLISHED);
				tsk->snd_una = cb->ack;
				tsk->rcv_nxt = cb->seq + 1;
				tcp_update_window_safe(tsk, cb);
				tcp_send_control_packet(tsk, TCP_ACK);
			}
			break;
		case TCP_SYN_RECV: // when a passively syned tcp sock receives a ACK packet
			if (cb->flags & TCP_ACK){ // shift the child_sock from listen_queue to accept_queue, wake up accept
				if (!tcp_sock_accept_queue_full(tsk)) {
					list_delete_entry(&tsk->list);
					init_list_head(&tsk->list);
					tcp_sock_accept_enqueue(tsk);

					tcp_set_state(tsk, TCP_ESTABLISHED);
		        	tsk->snd_una = cb->ack;
					tsk->rcv_nxt = cb->seq;
					tcp_update_window_safe(tsk, cb);
					wake_up(tsk->wait_accept);
				}
			}
			break;
		case TCP_ESTABLISHED: // when connection has established, client/server can send/recv data, or close connection
			if (cb->flags & TCP_ACK){ // Receive data and ACK, write into rcv_buf (lab15)
				if (cb->pl_len == 0) {
            		tsk->snd_una = cb->ack;
            		tsk->rcv_nxt = cb->seq + 1;
        		} else {
					process_recv_data(tsk, cb);
					if (less_than_32b(tsk->snd_una, cb->ack))
						tsk->snd_una = cb->ack;
					tcp_send_control_packet(tsk, TCP_ACK);
				}
				tcp_update_window_safe(tsk, cb);
			}
			if (cb->flags & TCP_FIN) { // Finish packet, passively closed
				tcp_set_state(tsk, TCP_CLOSE_WAIT);
				tsk->rcv_nxt = cb->seq + 1;
				tcp_send_control_packet(tsk, TCP_ACK);
			} 
			break;
		case TCP_FIN_WAIT_1: // when actively close node has sent FIN and receives ACK packet
			if (cb->flags & TCP_ACK){
				tcp_set_state(tsk, TCP_FIN_WAIT_2);
			}
			break;
		case TCP_FIN_WAIT_2: // when actively close node receives FIN packet, which means sender has no data to send 
			if (cb->flags & TCP_FIN){ // return ack, wait 2*MSL time to close.
				tcp_set_state(tsk, TCP_TIME_WAIT);
				tsk->rcv_nxt = cb->seq + 1;
				tcp_send_control_packet(tsk, TCP_ACK);
				tcp_set_timewait_timer(tsk);
			}
			break;
		case TCP_LAST_ACK: // when passively close node receives the last ACK packet for FIN, closed.
			if (cb->flags & TCP_ACK){
				tcp_set_state(tsk, TCP_CLOSED);
				tcp_unhash(tsk);
				tcp_bind_unhash(tsk);
			}
			break;

		default:
			break;
	}
}
