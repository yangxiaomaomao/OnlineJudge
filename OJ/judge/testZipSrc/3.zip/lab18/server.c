#include "base.h"
#include "ether.h"
#include "arp.h"
#include "arpcache.h"
#include "ip.h"
#include "rtable.h"
#include "tcp_sock.h"
#include "tcp_apps.h"

#include "log.h"

#include <stdlib.h>
#include <unistd.h>
#include <poll.h>
#include <net/if.h>
#include <ifaddrs.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <linux/if_packet.h>
#include <libgen.h>

#define FILENOTFOUND "HTTP/1.1 404 File not found\r\n\r\n"
#define FILEFOUND "HTTP/1.1 200 ok\r\n"
#define THREAD_NUM 8
#define MAXPATH 100
#define MAXMSG 2000

char* My_itoa(int value,char str[],int radix) 
{ 
    char temp[33]; 
    char *tp = temp; 
    int i; 
    unsigned v; 
    int sign; 
    char *sp; 
    if(radix > 36 || radix < 1) 
        return 0; 
    sign = (radix == 10 && value < 0); //十进制负数 
    if(sign) 
        v = -value; 
    else 
        v = (unsigned)value; 
    while(v || tp == temp)       //转化操作 
    { 
        i = v % radix; 
        v = v / radix; 
        if(i < 10) 
            *tp++ = i + '0'; 
        else 
            *tp++ = i + 'a' - 10; 
    } 
    if(str == 0) 
        str = (char*)malloc((tp - temp) + sign + 1); 
    sp = str; 
    if(sign)   //是负数的话把负号先加入数组 
        *sp++ = '-'; 
    while(tp > temp) 
        *sp++ = *--tp; 
    *sp = 0; 
 
  return str; 
}


int file_size(char* filename)
{
    FILE *fp = fopen(filename, "r");
    if(!fp)
    {
        return -1;
    }
    fseek(fp, 0L, SEEK_END);
    int size=ftell(fp);
    fclose(fp);
    return size;
}

void *handle_request(void *arg)
{
    int csockfd = *(int *)arg;
    printf("socketfd: %d------connection accepted\n", csockfd);

    FILE* fd;
    char msg[MAXMSG];
    char file_path[MAXPATH];
    msg[0] = 0;
    file_path[0] = 0;

    int msg_len = 0;
    // receive a message from client
    while((msg_len = recv(csockfd, msg, sizeof(msg), 0)) > 0)
    {
        msg[msg_len] = '\0';
        printf("%s\n", msg);

        char* p[20]; 
        p[0] = strtok(msg, " ");
        int i = 1;
        while((p[i] = strtok(NULL, " ")) != NULL)
        {
            i++;
        }
        strcat(file_path, ".");
        strcat(file_path, p[1]);

        if((fd = fopen(file_path, "r")) == NULL)
        {
            printf("404 File not found\n");
            printf("socketfd: %d------request finished\n", csockfd);
            write(csockfd, FILENOTFOUND, strlen(FILENOTFOUND));
            return NULL;
        }

        int fsize = file_size(file_path);
        char fsize_str[20];
        My_itoa(fsize, fsize_str, 10);

        strcpy(msg, FILEFOUND);
        strcat(msg, "Content-Length: ");
        strcat(msg, fsize_str);
        strcat(msg, "\r\n");
        strcat(msg, "Content-Type: text/html; charset=utf-8");
        strcat(msg, "\r\n\r\n");
        write(csockfd, msg, strlen(msg));

        // send data
        while (1)
        {
            memset(msg, 0, sizeof(msg));
            fread(msg, 1, 1024, fd);
            if(send(csockfd, msg, strlen(msg), 0) < 0)
            {
                printf("send failed");
                return NULL;
            }
            if(feof(fd))
                break;
        }

        fclose(fd);
    }  

    if (msg_len == 0)
    {
        printf("client disconnected\n");
    }
    else
    { // msg_len < 0
        perror("recv failed\n");
		return NULL;
    }

    printf("socketfd: %d------request finished\n", csockfd);

    return NULL;
}

int main(int argc, const char *argv[])
{
    if(argc > 2)
    {
        printf("cmd not permitted");
        return -1;
    }
    int port = 0;
    if(argc == 2)
    {
        port = atoi(argv[1]);
    }
    else
    {
        port = 80;
    }
    //int sockfd;
	struct tcp_sock* sockfd;
    struct sockaddr_in server/*, client*/;

    // create socket
    //if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	sockfd = alloc_tcp_sock();

    printf("socket created\n"); 

    // prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(port);

    // bind
/*    
	if (tcp_sock_bind(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("bind failed\n");
        return -1;
    }
*/
	tcp_sock_bind(sockfd, (struct sock_addr *)&server);
    printf("bind done\n");

    // listen
    tcp_sock_listen(sockfd, 1024);

    while(1)
    {
        printf("waiting for incoming connections...\n");

        //int c = sizeof(struct sockaddr_in);
        
        struct tcp_sock *cs;
		/*
        if((cs = accept(sockfd, (struct sockaddr *)&client, (socklen_t *)&c)) < 0)
            continue;
		*/
        if((cs = tcp_sock_accept(sockfd)) == NULL)
            continue;
        pthread_t *tid;
        tid = (pthread_t *)malloc(sizeof(pthread_t));
        pthread_create(tid, NULL, handle_request, &cs);
        sleep(1);
    }

    return 0;            
}

