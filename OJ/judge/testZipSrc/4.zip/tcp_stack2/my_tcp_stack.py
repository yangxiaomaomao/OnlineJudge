#!/usr/bin/python

import sys
import string
import socket
from time import sleep

def server(port):
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    s.bind(('0.0.0.0', int(port)))
    s.listen(3)

    cs, addr = s.accept()
    print addr
    fd = open("server-output.dat", "w+")
    fd.close()

    while True:
        data = cs.recv(1000)
        print(type(data))
        if data:
            with open("server-output.dat", "a+") as output_file:
                output_file.write(data)
                output_file.close()
        else:
            break

    s.close()

def client(ip, port):
    fp =  open("client-input.dat", "r")
    s = socket.socket()
    s.connect((ip, int(port)))
    i = 0

    print('debug')
    txt = fp.read(1000)
    while txt != "":
        s.send(bytes(txt))
        i += 1
        print('send packet {} finished'.format(i))
        txt = fp.read(1000)

    sleep(2)
    print('closing file')
    fp.close()
    s.close()

if __name__ == '__main__':
    if sys.argv[1] == 'server':
        server(sys.argv[2])
    elif sys.argv[1] == 'client':
        client(sys.argv[2], sys.argv[3])