#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <regex.h>
#include <pthread.h>

#include "tcp_sock.h"

void * handle_Request(void * arg) ;
struct mThread {
    pthread_t pid;
    int flag;
    struct sockaddr_in client;
    int addr_len;
    struct tcp_sock* request;
} pool[1];

struct mResponse {
    const char * status;
    int content_length;
    FILE * response_file;
};



// int main(int argc, char * argv[]) {
void *tcp_server(void *arg){
    struct sockaddr_in server;
//create socket
    //int sockfd;
    // if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    //     perror("Create socket failed");
	// 	return -1;
    // }
    struct tcp_sock *tsk = alloc_tcp_sock();
	printf("socket created!\r\n");

//bind
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(80);

    struct sock_addr saddr;
    saddr.ip = htonl(0);
    saddr.port = htons(80);

    // if (bind(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0) {
    //     perror("bind failed");
    //     return -1;
    // }
    if (tcp_sock_bind(tsk, &saddr) < 0) {//todo
        perror("bind failed");
        return NULL;
    }
	printf("bind succeed!\r\n");

//listen
    tcp_sock_listen(tsk, 3);
    printf("Servering HTTP on 0.0.0.0 port 80 ...\n");

//create thread when receiving request
    while (1) {
        for (int i = 0; i < 1; i++) {
            if (!pool[i].flag) {
                //pool[i].request = accept(sockfd, (struct sockaddr *)&pool[i].client, (socklen_t *)&pool[i].addr_len);
                pool[i].request = tcp_sock_accept(tsk);
                pool[i].flag = 1;
                pthread_create(&pool[i].pid, NULL, handle_Request, pool + i);
            }
        }
    }

    return 0;
}

//handle request
void * handle_Request(void * arg) {
    pthread_detach(pthread_self());
    struct mThread * current_req = arg;

    char * recv_buff = malloc(2000);
    //int recv_len = recv(current_req->request, recv_buff, 2000, 0);
    int recv_len = tcp_sock_read(current_req->request, recv_buff, 2000);
    if (recv_len < 0) {
        fprintf(stderr, "Recv failed.");
        current_req->flag = 0;
        return NULL;
    }

    char * line_start = recv_buff;


    char method[10];
    char path[100];
    char ver[10];
    sscanf(line_start, "%s %s %s", method, path, ver);

    struct mResponse resp;
    char * send_buff = malloc(4000);
    char * file_buff = malloc(2000);

    FILE * fd = fopen(path + 1, "r");
    if (fd == NULL) {
        resp.status = "404 Not Found";
        resp.content_length = 0;
    } else {
        resp.status = "200 OK";
        char ch;
        int len = 0;
        while ((ch = fgetc(fd)) != EOF && len < 2000)  {
            file_buff[len] = ch;
            len ++;
        }
        file_buff[len] = 0;
        resp.content_length = len;
    }


    int len = 0;
    len += sprintf(send_buff + len, "HTTP/1.1 %s\r\n", resp.status);
    len += sprintf(send_buff + len, "Content-Length: %d\r\n", resp.content_length);
    len += sprintf(send_buff + len, "\r\n");

    len += sprintf(send_buff + len, "%s", file_buff);

    // if (send(current_req->request, send_buff, len, 0) < 0) {
    if (tcp_sock_write(current_req->request, send_buff, len) < 0) {
        fprintf(stderr, "send failed");
        return NULL;
    }
    printf("%s - ", inet_ntoa(current_req->client.sin_addr));
    printf("\"%s %s %s\"", method, path, ver);
    printf(" -- %s\n", resp.status);
    
    free(recv_buff);
    free(send_buff);
    free(file_buff);
    current_req->flag = 0;
    return NULL;
}


void *tcp_client(void *arg)
{
	return NULL;	
}

// #endif
// #include "tcp_sock.h"
// #include "log.h"

// #include <unistd.h>

// #define TEST_FILE
// #define UNIT_LEN 1000

// #ifdef TEST_FILE

// void *tcp_server(void *arg) {
//     u16 port = *(u16 *) arg;
//     struct tcp_sock *tsk = alloc_tcp_sock();

//     struct sock_addr saddr;
//     saddr.ip = htonl(0);
//     saddr.port = port;
//     if (tcp_sock_bind(tsk, &saddr) < 0) {
//         log(ERROR, "tcp_sock bind to port %hu failed", ntohs(port));
//         exit(1);
//     }
//     if (tcp_sock_listen(tsk, 3) < 0) {
//         log(ERROR, "tcp_sock listen failed");
//         exit(1);
//     }

//     log(DEBUG, "listen to port %hu.", ntohs(port));

//     struct tcp_sock *socket = tcp_sock_accept(tsk);

//     log(DEBUG, "accept a connection.");

//     char rbuf[UNIT_LEN + 1];
//     int rlen = 0;
//     //delete file
//     FILE *fp = fopen("server-output.dat", "w+");
//     fclose(fp);
//     if (fp == NULL) {
//         printf("server open file failed");
//         exit(1);
//     }
//     while (1) {
//         bzero(rbuf, UNIT_LEN + 1);
//         rlen = tcp_sock_read(socket, rbuf, UNIT_LEN);
//         if (rlen == 0) {
//             log(DEBUG, "tcp_sock_read return 0, finish transmission.");
//             break;
//         } else if (rlen > 0) {
//             rbuf[rlen] = '\0';
//             FILE *fp_now = fopen("server-output.dat", "a+");
//             fprintf(fp_now, "%s", rbuf);
//             fclose(fp_now);
//         } else if (rlen < 0) {
//             log(DEBUG, "tcp_sock_read return negative value, something goes wrong.");
//             exit(1);
//         }
//     }
//     log(DEBUG, "close this connection.");
//     tcp_sock_close(socket);

//     return NULL;
// }


// void *tcp_client(void *arg) {
//     struct sock_addr *skaddr = arg;
//     struct tcp_sock *tsk = alloc_tcp_sock();

//     if (tcp_sock_connect(tsk, skaddr) < 0) {
//         log(ERROR, "tcp_sock connect to server ("IP_FMT":%hu)failed.", \
//                 NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));
//         exit(1);
//     }

//     FILE *fp = fopen("client-input.dat", "r");
//     if (fp == NULL) {
//         printf("client open file failed\n");
//         exit(1);
//     }

//     char wbuf[UNIT_LEN + 1];
//     u32 wlen = 0;
//     int i = 0;
//     while (!feof(fp)) {    // until the end
//         wlen = fread(wbuf, 1, UNIT_LEN, fp);    // everytime 1kB
//         printf("debug read bytes: %d\n", wlen);
//         if (tcp_sock_write(tsk, wbuf, wlen) < 0)
//             break;
//         // sleep(1);
//         printf("send packet %d finished\n", i++);
//     }

//     sleep(2);
//     printf("Closing file.\n");
//     fclose(fp);
//     tcp_sock_close(tsk);

//     return NULL;
// }

// #else
// // tcp server application, listens to port (specified by arg) and serves only one
// // connection request
// void *tcp_server(void *arg)
// {
//     u16 port = *(u16 *)arg;
//     struct tcp_sock *tsk = alloc_tcp_sock();

//     struct sock_addr addr;
//     addr.ip = htonl(0);
//     addr.port = port;
//     if (tcp_sock_bind(tsk, &addr) < 0) {
//         log(ERROR, "tcp_sock bind to port %hu failed", ntohs(port));
//         exit(1);
//     }

//     if (tcp_sock_listen(tsk, 3) < 0) {
//         log(ERROR, "tcp_sock listen failed");
//         exit(1);
//     }

//     log(DEBUG, "listen to port %hu.", ntohs(port));

//     struct tcp_sock *csk = tcp_sock_accept(tsk);

//     log(DEBUG, "accept a connection.");
//     //expr 12
//     char rbuf[1001];
//     char wbuf[1024];
//     int rlen = 0;
//     while (1) {
//         rlen = tcp_sock_read(csk, rbuf, 1000);
//         if (rlen == 0) {
//             log(DEBUG, "tcp_sock_read return 0, finish transmission.");
//             break;
//         }
//         else if (rlen > 0) {
//             rbuf[rlen] = '\0';
//             sprintf(wbuf, "server echoes: %s", rbuf);
//             if (tcp_sock_write(csk, wbuf, strlen(wbuf)) < 0) {
//                 log(DEBUG, "tcp_sock_write return negative value, something goes wrong.");
//                 exit(1);
//             }
//         }
//         else {
//             log(DEBUG, "tcp_sock_read return negative value, something goes wrong.");
//             exit(1);
//         }
//     }
// //    sleep(5);
//     log(DEBUG, "close this connection.");

//     tcp_sock_close(csk);

//     return NULL;
// }

// // tcp client application, connects to server (ip:port specified by arg), each
// // time sends one bulk of data and receives one bulk of data
// void *tcp_client(void *arg)
// {
//     struct sock_addr *skaddr = arg;

//     struct tcp_sock *tsk = alloc_tcp_sock();

//     if (tcp_sock_connect(tsk, skaddr) < 0) {
//         log(ERROR, "tcp_sock connect to server ("IP_FMT":%hu)failed.", \
//                 NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));
//         exit(1);
//     }

//     char *wbuf = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
//     int wlen = strlen(wbuf);
//     char rbuf[1001];
//     int rlen = 0;

//     int n = 10;
//     for (int i = 0; i < n; i++) {
//         if (tcp_sock_write(tsk, wbuf + i, wlen - n) < 0)
//             break;

//         rlen = tcp_sock_read(tsk, rbuf, 1000);
//         if (rlen == 0) {
//             log(DEBUG, "tcp_sock_read return 0, finish transmission.");
//             break;
//         }
//         else if (rlen > 0) {
//             rbuf[rlen] = '\0';
//             fprintf(stdout, "%s\n", rbuf);
//         }
//         else {
//             log(DEBUG, "tcp_sock_read return negative value, something goes wrong.");
//             exit(1);
//         }
//         sleep(1);
//     }

// //    sleep(1);
//     tcp_sock_close(tsk);

//     return NULL;
// }

// #endif
