#include "tcp.h"
#include "tcp_sock.h"
#include "tcp_timer.h"

#include "log.h"
#include "ring_buffer.h"

#include <stdlib.h>

// update the snd_wnd of tcp_sock
//
// if the snd_wnd before updating is zero, notify tcp_sock_send (wait_send)
static inline void tcp_update_window(struct tcp_sock *tsk, struct tcp_cb *cb) {
    u16 old_snd_wnd = tsk->snd_wnd;
    tsk->snd_wnd = cb->rwnd;
    if (old_snd_wnd == 0)
        wake_up(tsk->wait_send);
}

// update the snd_wnd safely: cb->ack should be between snd_una and snd_nxt
static inline void tcp_update_window_safe(struct tcp_sock *tsk, struct tcp_cb *cb) {
    if (less_or_equal_32b(tsk->snd_una, cb->ack) && less_or_equal_32b(cb->ack, tsk->snd_nxt))
        tcp_update_window(tsk, cb);
}

#ifndef max
#	define max(x, y) ((x)>(y) ? (x) : (y))
#endif

// check whether the sequence number of the incoming packet is in the receiving
// window
static inline int is_tcp_seq_valid(struct tcp_sock *tsk, struct tcp_cb *cb) {
    u32 rcv_end = tsk->rcv_nxt + max(tsk->rcv_wnd, 1);
    if (less_than_32b(cb->seq, rcv_end) && less_or_equal_32b(tsk->rcv_nxt, cb->seq_end)) {
        return 1;
    } else {
        log(ERROR, "received packet with invalid seq, drop it.");
        return 0;
    }
}

// handling incoming packet for TCP_LISTEN state
//
// 1. malloc a child tcp sock to serve this connection request;
// 2. send TCP_SYN | TCP_ACK by child tcp sock;
// 3. hash the child tcp sock into established_table (because the 4-tuple
//    is determined).
void tcp_state_listen(struct tcp_sock *tsk, struct tcp_cb *cb) {
    if (cb->flags & TCP_SYN) {
        struct tcp_sock *child_sock = alloc_tcp_sock();
        child_sock->local.ip = cb->daddr;
        child_sock->local.port = cb->dport;
        child_sock->peer.ip = cb->saddr;
        child_sock->peer.port = cb->sport;

        child_sock->parent = tsk;
        child_sock->rcv_nxt = cb->seq_end;
        child_sock->iss = tcp_new_iss();
        child_sock->snd_nxt = child_sock->iss;

        struct sock_addr skaddr = {htonl(child_sock->sk_sip), htons(child_sock->sk_sport)};
        tcp_sock_bind(child_sock, &skaddr);
        tcp_set_state(child_sock, TCP_SYN_RECV);
        list_add_tail(&child_sock->list, &tsk->listen_queue);
        tcp_send_control_packet(child_sock, TCP_SYN | TCP_ACK);
        tcp_hash(child_sock);
    } else
        tcp_send_reset(cb);

}

void tcp_rcv_data(struct tcp_sock *tsk, struct tcp_cb *cb, char *packet) {
    pthread_mutex_lock(&tsk->rcv_buf->rw_lock);
    write_ring_buffer(tsk->rcv_buf, cb->payload, cb->pl_len);
    tsk->rcv_wnd -= cb->pl_len;
    pthread_mutex_unlock(&tsk->rcv_buf->rw_lock);
    if (!ring_buffer_empty(tsk->rcv_buf))
        wake_up(tsk->wait_recv);
}

// Process the incoming packet according to TCP state machine. 
void tcp_process(struct tcp_sock *tsk, struct tcp_cb *cb, char *packet) {

    int state = tsk->state;
    switch (state) {
        case TCP_CLOSED:
            tcp_send_reset(cb);
            return;
        case TCP_LISTEN:
            tcp_state_listen(tsk, cb);
            return;
        case TCP_SYN_SENT:
// handling incoming packet for TCP_SYN_SENT state
            if (cb->flags & (TCP_SYN | TCP_ACK)) {
                // reply with TCP_ACK, and enter TCP_ESTABLISHED state
                tsk->rcv_nxt = cb->seq_end;
                tsk->snd_una = cb->ack;
                tcp_set_state(tsk, TCP_ESTABLISHED);
                tcp_send_control_packet(tsk, TCP_ACK);
                wake_up(tsk->wait_connect);
            } else
                tcp_send_reset(cb);
            return;
        default:
            break;
    }

    if (!is_tcp_seq_valid(tsk, cb)) {
        log(ERROR, "[tcp_process]: detect window.\n");
        return;
    }

    if (cb->flags & TCP_RST) {
        tcp_set_state(tsk, TCP_CLOSED);
        tcp_unhash(tsk);
        return;
    }
    if (cb->flags & TCP_SYN) {
        tcp_set_state(tsk, TCP_CLOSED);
        tcp_send_reset(cb);
        return;
    }
    if (!(cb->flags & TCP_ACK)) {
        tcp_send_reset(cb);
        log(ERROR, "[tcp_process]: TCP_ACK is not set.\n");
        return;
    }

    tsk->snd_una = cb->ack;
    tsk->rcv_nxt = cb->seq_end;

    // SYN_RCVD -> ESTABLISHED
    if (state == TCP_SYN_RECV && cb->ack == tsk->snd_nxt) {
        // handling incoming ack packet for tcp sock in TCP_SYN_RECV state
        if (cb->flags & TCP_ACK) {
            tcp_set_state(tsk, TCP_ESTABLISHED);
            tcp_sock_accept_enqueue(tsk);
            wake_up(tsk->parent->wait_accept);
        } else {
            tcp_send_reset(cb);
        }
    }
    // FIN_WAIT_1 -> FIN_WAIT_2
    if (state == TCP_FIN_WAIT_1 && cb->ack == tsk->snd_nxt)
        tcp_set_state(tsk, TCP_FIN_WAIT_2);
    // FIN_WAIT_2 -> TIME_WAIT
    if (state == TCP_FIN_WAIT_2 && cb->flags & TCP_FIN) {
        tcp_set_state(tsk, TCP_TIME_WAIT);
        tcp_set_timewait_timer(tsk);
        tcp_send_control_packet(tsk, TCP_ACK);
    }
    // ESTABLISHED -> CLOSE_WAIT
    if (state == TCP_ESTABLISHED) {
        if (cb->flags & TCP_FIN) {
            tcp_set_state(tsk, TCP_CLOSE_WAIT);
            tcp_send_control_packet(tsk, TCP_ACK);
            if (!ring_buffer_empty(tsk->rcv_buf)) {
                wake_up(tsk->wait_recv);
            }
            tcp_set_state(tsk, TCP_LAST_ACK);
            tcp_send_control_packet(tsk, TCP_FIN | TCP_ACK);
        }
        if (cb->flags & TCP_ACK) {
            if (cb->ack == tsk->snd_nxt)
                wake_up(tsk->wait_send);
            if (cb->flags & TCP_PSH || cb->pl_len != 0) {
                tcp_rcv_data(tsk, cb, packet);
                tcp_send_control_packet(tsk, TCP_ACK);
            }
        }
    }
    // LAST_ACK -> CLOSED
    if (state == TCP_LAST_ACK && cb->ack == tsk->snd_nxt)
        tcp_set_state(tsk, TCP_CLOSED);
}
