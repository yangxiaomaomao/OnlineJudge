#include "tcp.h"
#include "tcp_hash.h"
#include "tcp_sock.h"
#include "tcp_timer.h"
#include "ip.h"
#include "rtable.h"
#include "log.h"

// TCP socks should be hashed into table for later lookup: Those which
// occupy a port (either by *bind* or *connect*) should be hashed into
// bind_table, those which listen for incoming connection request should be
// hashed into listen_table, and those of established connections should
// be hashed into established_table.

struct tcp_hash_table tcp_sock_table;
#define tcp_established_sock_table    tcp_sock_table.established_table
#define tcp_listen_sock_table        tcp_sock_table.listen_table
#define tcp_bind_sock_table            tcp_sock_table.bind_table

inline void tcp_set_state(struct tcp_sock *tsk, int state) {
    log(DEBUG, IP_FMT":%hu switch state, from %s to %s.", \
            HOST_IP_FMT_STR(tsk->sk_sip), tsk->sk_sport, \
            tcp_state_str[tsk->state], tcp_state_str[state]);
    tsk->state = state;
}

// init tcp hash table and tcp timer
void init_tcp_stack() {
    for (int i = 0; i < TCP_HASH_SIZE; i++)
        init_list_head(&tcp_established_sock_table[i]);

    for (int i = 0; i < TCP_HASH_SIZE; i++)
        init_list_head(&tcp_listen_sock_table[i]);

    for (int i = 0; i < TCP_HASH_SIZE; i++)
        init_list_head(&tcp_bind_sock_table[i]);

    pthread_t timer;
    pthread_create(&timer, NULL, tcp_timer_thread, NULL);
}

// allocate tcp sock, and initialize all the variables that can be determined
// now
struct tcp_sock *alloc_tcp_sock() {
    struct tcp_sock *tsk = malloc(sizeof(struct tcp_sock));

    memset(tsk, 0, sizeof(struct tcp_sock));

    tsk->state = TCP_CLOSED;
    tsk->rcv_wnd = TCP_DEFAULT_WINDOW;

    init_list_head(&tsk->list);
    init_list_head(&tsk->listen_queue);
    init_list_head(&tsk->accept_queue);

    tsk->rcv_buf = alloc_ring_buffer(tsk->rcv_wnd);

    tsk->wait_connect = alloc_wait_struct();
    tsk->wait_accept = alloc_wait_struct();
    tsk->wait_recv = alloc_wait_struct();
    tsk->wait_send = alloc_wait_struct();

    return tsk;
}

// release all the resources of tcp sock
//
// To make the stack run safely, each time the tcp sock is refered (e.g. hashed), 
// the ref_cnt is increased by 1. each time free_tcp_sock is called, the ref_cnt
// is decreased by 1, and release the resources practically if ref_cnt is
// decreased to zero.
void free_tcp_sock(struct tcp_sock *tsk) {
    tsk->ref_cnt -= 1;
    if (tsk->ref_cnt <= 0) {
        log(DEBUG, "ref_cnt is %d", tsk->ref_cnt);
        log(DEBUG, "free tcp sock: ["IP_FMT":%hu<->"IP_FMT":%hu].", \
                HOST_IP_FMT_STR(tsk->sk_sip), (tsk->sk_sport),
            HOST_IP_FMT_STR(tsk->sk_dip), (tsk->sk_dport));

        free_ring_buffer(tsk->rcv_buf);

        free_wait_struct(tsk->wait_recv);
        free_wait_struct(tsk->wait_send);
        free_wait_struct(tsk->wait_connect);
        free_wait_struct(tsk->wait_accept);

        free(tsk);
    }
}

// lookup tcp sock in established_table with key (saddr, daddr, sport, dport)
struct tcp_sock *tcp_sock_lookup_established(u32 saddr, u32 daddr, u16 sport, u16 dport) {
    int key = tcp_hash_function(saddr, daddr, sport, dport);
    struct tcp_sock *sk_pos, *sk_q;
    list_for_each_entry_safe(sk_pos, sk_q,
                             &tcp_established_sock_table[key], hash_list) {
        if (saddr == sk_pos->local.ip && daddr == sk_pos->peer.ip
            && sport == sk_pos->local.port && dport == sk_pos->peer.port) {
            return sk_pos;
        }
    }
    return NULL;
}

// lookup tcp sock in listen_table with key (sport)
//
// In accordance with BSD socket, saddr is in the argument list, but never used.
struct tcp_sock *tcp_sock_lookup_listen(u32 saddr, u16 sport) {
    u8 key = tcp_hash_function(0, 0, sport, 0);
    struct tcp_sock *sk_pos, *sk_q;
    list_for_each_entry_safe(sk_pos, sk_q, &tcp_listen_sock_table[key], hash_list) {
        if (sk_pos->local.port == sport) {
            return sk_pos;
        }
    }
    return NULL;
}

// lookup tcp sock in both established_table and listen_table
struct tcp_sock *tcp_sock_lookup(struct tcp_cb *cb) {
    u32 saddr = cb->daddr,
            daddr = cb->saddr;
    u16 sport = cb->dport,
            dport = cb->sport;

    struct tcp_sock *tsk = tcp_sock_lookup_established(saddr, daddr, sport, dport);
    if (!tsk)
        tsk = tcp_sock_lookup_listen(saddr, sport);

    return tsk;
}

// hash tcp sock into bind_table, using sport as the key
static int tcp_bind_hash(struct tcp_sock *tsk) {
    int bind_hash_value = tcp_hash_function(0, 0, tsk->sk_sport, 0);
    struct list_head *list = &tcp_bind_sock_table[bind_hash_value];
    list_add_head(&tsk->bind_hash_list, list);

    tsk->ref_cnt += 1;

    return 0;
}

// unhash the tcp sock from bind_table
void tcp_bind_unhash(struct tcp_sock *tsk) {
    if (!list_empty(&tsk->bind_hash_list)) {
        list_delete_entry(&tsk->bind_hash_list);
        free_tcp_sock(tsk);
    }
}

// lookup bind_table to check whether sport is in use
static int tcp_port_in_use(u16 sport) {
    int value = tcp_hash_function(0, 0, sport, 0);
    struct list_head *list = &tcp_bind_sock_table[value];
    struct tcp_sock *tsk;
    list_for_each_entry(tsk, list, hash_list) {
        if (tsk->sk_sport == sport)
            return 1;
    }

    return 0;
}

// find a free port by looking up bind_table
static u16 tcp_get_port() {
    for (u16 port = PORT_MIN; port < PORT_MAX; port++) {
        if (!tcp_port_in_use(port))
            return port;
    }

    return 0;
}

// tcp sock tries to use port as its source port
static int tcp_sock_set_sport(struct tcp_sock *tsk, u16 port) {
    if ((port && tcp_port_in_use(port)) ||
        (!port && !(port = tcp_get_port())))
        return -1;

    tsk->sk_sport = port;

    tcp_bind_hash(tsk);

    return 0;
}

// hash tcp sock into either established_table or listen_table according to its
// TCP_STATE
int tcp_hash(struct tcp_sock *tsk) {
    struct list_head *list;
    int hash;

    if (tsk->state == TCP_CLOSED)
        return -1;

    if (tsk->state == TCP_LISTEN) {
        hash = tcp_hash_function(0, 0, tsk->sk_sport, 0);
        list = &tcp_listen_sock_table[hash];
    } else {
        int hash = tcp_hash_function(tsk->sk_sip, tsk->sk_dip, \
                tsk->sk_sport, tsk->sk_dport);
        list = &tcp_established_sock_table[hash];

        struct tcp_sock *tmp;
        list_for_each_entry(tmp, list, hash_list) {
            if (tsk->sk_sip == tmp->sk_sip &&
                tsk->sk_dip == tmp->sk_dip &&
                tsk->sk_sport == tmp->sk_sport &&
                tsk->sk_dport == tmp->sk_dport)
                return -1;
        }
    }

    list_add_head(&tsk->hash_list, list);
    tsk->ref_cnt += 1;

    return 0;
}

// unhash tcp sock from established_table or listen_table
void tcp_unhash(struct tcp_sock *tsk) {
    if (!list_empty(&tsk->hash_list)) {
        list_delete_entry(&tsk->hash_list);
        free_tcp_sock(tsk);
    }
}

// XXX: skaddr here contains network-order variables
int tcp_sock_bind(struct tcp_sock *tsk, struct sock_addr *skaddr) {
    int err = 0;

    // omit the ip address, and only bind the port
    err = tcp_sock_set_sport(tsk, ntohs(skaddr->port));

    return err;
}

// connect to the remote tcp sock specified by skaddr
//
// XXX: skaddr here contains network-order variables
// 4. if the SYN packet of the peer arrives, this function is notified, which
//    means the connection is established.
int tcp_sock_connect(struct tcp_sock *tsk, struct sock_addr *skaddr) {
    // 1. initialize the four key tuple (sip, sport, dip, dport);
    tsk->peer.ip = ntohl(skaddr->ip);
    tsk->peer.port = ntohs(skaddr->port);
    tsk->local.ip = ((iface_info_t *) (instance->iface_list.next))->ip;
    if (tcp_sock_set_sport(tsk, tcp_get_port()) < 0) {
        printf("[tcp_sock_connect] Set port failed.\n");
        return -1;
    }
// 2. hash the tcp sock into bind_table;
// 3. send SYN packet, switch to TCP_SYN_SENT state, wait for the incoming
//    SYN packet by sleep on wait_connect;
    tsk->iss = tcp_new_iss();
    tsk->snd_nxt = tsk->iss;
    tcp_set_state(tsk, TCP_SYN_SENT);
    tcp_hash(tsk);
    tcp_send_control_packet(tsk, TCP_SYN);
    sleep_on(tsk->wait_connect);

    return 0;
}

int tcp_sock_listen(struct tcp_sock *tsk, int backlog) {
    // set backlog (the maximum number of pending connection requst)
    tsk->backlog = backlog;
    //switch the TCP_STATE
    tcp_set_state(tsk, TCP_LISTEN);
    //hash the tcp sock into listen_table
    int err = tcp_hash(tsk);
    return err;
}

// check whether the accept queue is full
inline int tcp_sock_accept_queue_full(struct tcp_sock *tsk) {
    if (tsk->accept_backlog >= tsk->backlog) {
        log(ERROR, "tcp accept queue (%d) is full.", tsk->accept_backlog);
        return 1;
    }

    return 0;
}

// push the tcp sock into accept_queue
inline void tcp_sock_accept_enqueue(struct tcp_sock *tsk) {
    if (!list_empty(&tsk->list))
        list_delete_entry(&tsk->list);
    list_add_tail(&tsk->list, &tsk->parent->accept_queue);
    tsk->parent->accept_backlog += 1;
}

// pop the first tcp sock of the accept_queue
inline struct tcp_sock *tcp_sock_accept_dequeue(struct tcp_sock *tsk) {
    struct tcp_sock *new_tsk = list_entry(tsk->accept_queue.next, struct tcp_sock, list);
    list_delete_entry(&new_tsk->list);
    init_list_head(&new_tsk->list);
    tsk->accept_backlog -= 1;

    return new_tsk;
}

// if accept_queue is not emtpy, pop the first tcp sock and accept it,
// otherwise, sleep on the wait_accept for the incoming connection requests
struct tcp_sock *tcp_sock_accept(struct tcp_sock *tsk) {

    if (!tsk->accept_backlog) {
        sleep_on(tsk->wait_accept);
    }
    if (tsk->accept_backlog) {
        struct tcp_sock *accept_tsk = tcp_sock_accept_dequeue(tsk);
//        tcp_set_state(accept_tsk, TCP_ESTABLISHED);
        return accept_tsk;
    }
    return NULL;
}

// clear the listen queue, which is carried out when *close* the tcp sock
static void tcp_sock_clear_listen_queue(struct tcp_sock *tsk) {
    struct tcp_sock *lstn_tsk;
    while (!list_empty(&tsk->listen_queue)) {
        lstn_tsk = list_entry(tsk->listen_queue.next, struct tcp_sock, list);
        list_delete_entry(&lstn_tsk->list);

        if (lstn_tsk->state == TCP_SYN_RECV) {
            lstn_tsk->parent = NULL;
            tcp_unhash(lstn_tsk);
            free_tcp_sock(lstn_tsk);
        }
    }
}

// close the tcp sock, by releasing the resources, sending FIN/RST packet
// to the peer, switching TCP_STATE to closed
void tcp_sock_close(struct tcp_sock *tsk) {
    log(DEBUG, "current state %s is closed", tcp_state_str[tsk->state]);
    switch (tsk->state) {
        case TCP_CLOSED:
        case TCP_SYN_RECV:
        case TCP_SYN_SENT:
            break;
        case TCP_LISTEN:
            tcp_sock_clear_listen_queue(tsk);
            tcp_unhash(tsk);
            tcp_set_state(tsk, TCP_CLOSED);
            break;
        case TCP_ESTABLISHED:
            tcp_send_control_packet(tsk, TCP_FIN | TCP_ACK);
            tcp_set_state(tsk, TCP_FIN_WAIT_1);
            break;
        case TCP_CLOSE_WAIT:
            tcp_send_control_packet(tsk, TCP_FIN | TCP_ACK);
            tcp_set_state(tsk, TCP_LAST_ACK);
            break;
    }
}

//int debugi = 0;

int tcp_sock_read(struct tcp_sock *tsk, char *buf, int len) {
    if (ring_buffer_empty(tsk->rcv_buf)) {
       // printf("tcp_sock_read, sleeping\n");
        sleep_on(tsk->wait_recv);
    }
    if (ring_buffer_empty(tsk->rcv_buf)) {
        //printf("tcp_sock_read, sleeping\n");
        sleep_on(tsk->wait_recv);
    }
    pthread_mutex_lock(&tsk->rcv_buf->rw_lock);
    int read_len = read_ring_buffer(tsk->rcv_buf, buf, len);
    tsk->rcv_wnd = min(tsk->rcv_wnd + read_len, 30000);
    pthread_mutex_unlock(&tsk->rcv_buf->rw_lock);
//    debugi++;
//    int RBU = ring_buffer_used(tsk->rcv_buf);
//    printf("debug cnt:%d len:%d, read len:%d rbu: %d\n", debugi, len, read_len, RBU);

    return read_len;
}


int tcp_sock_write(struct tcp_sock *tsk, char *buf, int len) {
    // int sent_len = 0;		// 已经发送的长度
    // while(sent_len < len)

    // int left_len = len - sent_len;	// 剩下待发送长度
    int data_len = min(len, ETH_FRAME_LEN - ETHER_HDR_SIZE -
                            IP_BASE_HDR_SIZE - TCP_BASE_HDR_SIZE);
    int pkt_len = ETHER_HDR_SIZE + IP_BASE_HDR_SIZE + TCP_BASE_HDR_SIZE + data_len;

    char *packet = (char *) malloc(pkt_len);
    memset(packet, 0, pkt_len);
    // 把buf拷贝到packet对应位置
    memcpy(packet + pkt_len - data_len, buf, data_len);

    tcp_send_packet(tsk, packet, pkt_len);

    sleep_on(tsk->wait_send);

    return data_len;
}
