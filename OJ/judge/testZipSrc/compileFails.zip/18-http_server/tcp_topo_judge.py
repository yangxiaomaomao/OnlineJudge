#!/usr/bin/python
import logging
import os
import sys
import glob


from mininet.topo import Topo
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.cli import CLI
import test_tools
import shutil

script_deps = ['ethtool', 'arptables', 'iptables']

TEST_DIR = "/home/zyk/network_exp/18/origin/18-http_server"
WORKING_DIR = "/home/zyk/network_exp/18/"

def check_scripts():
    dir = os.path.abspath(os.path.dirname(sys.argv[0]))

    for fname in glob.glob(dir + '/' + 'scripts/*.sh'):
        if not os.access(fname, os.X_OK):
            print '%s should be set executable by using `chmod +x $script_name`' % (fname)
            sys.exit(1)

    for program in script_deps:
        found = False
        for path in os.environ['PATH'].split(os.pathsep):
            exe_file = os.path.join(path, program)
            if os.path.isfile(exe_file) and os.access(exe_file, os.X_OK):
                found = True
                break
        if not found:
            print '`%s` is required but missing, which could be installed via `apt` or `aptitude`' % (program)
            sys.exit(2)


class TCPTopo(Topo):
    def build(self):
        h1 = self.addHost('h1')
        h2 = self.addHost('h2')

        self.addLink(h1, h2, delay='1ms')

class TCPLossTopo(Topo):
    def build(self):
        h1 = self.addHost('h1')
        h2 = self.addHost('h2')

        self.addLink(h1, h2, delay='1ms', loss=2)

def judge_with_topo(topo,server_file):
    check_scripts()
    net = Mininet(topo=topo, link=TCLink, controller=None)

    h1, h2 = net.get('h1', 'h2')
    h1.cmd('ifconfig h1-eth0 10.0.0.1/24')
    h2.cmd('ifconfig h2-eth0 10.0.0.2/24')

    for h in (h1, h2):
        h.cmd('scripts/disable_ipv6.sh')
        h.cmd('scripts/disable_offloading.sh')
        h.cmd('scripts/disable_tcp_rst.sh')
        # XXX: If you want to run user-level stack, you should execute
        # disable_[arp,icmp,ip_forward].sh first.

    net.start()
    # verify result here
    test_tools.test_case_18(h1, h2, server_file)
    net.stop()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    runnable_files = test_tools.read_runnable_files(WORKING_DIR)
    for server_file in runnable_files:
        loss_topo = TCPLossTopo()
        no_loss_topo = TCPTopo()
        # todo: copy runnable server file to local directory
        for topo in [loss_topo,no_loss_topo]:
            judge_with_topo(topo,server_file)

