# coding=utf-8
import os
import fnmatch
import test_tools
import logging
WORKING_DIR = "/home/zyk/network_exp/18/"
def find_students_dir(formatted_dir): # todo: 只能搜索到有 Makefile 的同学, 有的同学可能没有提交带有 Makefile 的文件, 待处理
    students_dir = []
    for dirpath,dirnames,files in os.walk(formatted_dir):
        # 当前文件夹下如果有 Makefile 当前文件夹为目标文件夹
        if len(fnmatch.filter(files, "Makefile")) >0:
            students_dir.append(dirpath)
    return students_dir

def make_in_dir(d):
    ret = os.system("make -C {}".format(d))
    if ret == 0:
        logging.debug("Make success for dir:{}".format(d))
    else:
        logging.info("make return :{} for {}".format(ret, d))
    return ret

def _test_make_in_dir():
    test_dir1 = "/home/zyk/network_exp/18/formatted_files/丁强/18-http-server"
    test_dir2 = "/home/zyk/network_exp/18/formatted_files/谭必得/×éºÏ¶þ"
    for d in [test_dir1, test_dir2]:
        make_in_dir(d)


def compile_formatted_files(formatted_files):
    make_success_dirs = []
    make_failed_dirs = []
    for d in find_students_dir(formatted_files):
        # compile and get result
        if make_in_dir(d) == 0:
            make_success_dirs.append(d)
        else:
            make_failed_dirs.append(d)
    logging.info("success :{}\n failed:{}".format(len(make_success_dirs), len(make_failed_dirs)))
    return make_success_dirs


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    formatted_files = "/home/zyk/network_exp/18/formatted_files"
    success_dirs = compile_formatted_files(formatted_files)

    valid_target_paths = []
    for dir in success_dirs:
        target_name = test_tools.parse_target("{}/Makefile".format(dir))
        if target_name:
            target_path = "{}/{}".format(dir,target_name)
            valid_target_paths.append(target_path)
            # logging.debug("target: {}/{}".format(dir, target_name))
        else:
            logging.error("Interesting, check this dir:{}".format(dir))
    logging.debug(valid_target_paths)
    test_tools.runnable_files_to_json(valid_target_paths,WORKING_DIR)




