
def test_case(h1,h2):
    h1.cmd("./http &")
    h2.cmd("wget 10.0.0.1")