# coding=utf-8
import time
import re
import logging
import os
import json

def download_files(host, target_url, file_list, download_dir=None):
    """

    :param host:
    :param target_url: e.g. "http://10.0.0.1/"
    :param file_list:
    :return:
    """
    if target_url[-1] != "/":
        target_url = target_url + "/"
    if download_dir:
        # make a new dir in python and
        os.mkdir("./{}".format(download_dir))
    else:
        download_dir = ""
    downloaded_files = []
    for file in file_list:
        ret = host.cmd("wget -O {dir}/{filename} {url}{filename}".format(dir="./{}".format(download_dir),url=target_url, filename=file))
        if "saved" in ret:
            logging.info ("{} download successfully".format(file))
            downloaded_files.append(file)
        else:
            logging.info ("cannot download {}".format(file))
    return downloaded_files

def get_md5(host, path_to_file):
    ret = host.cmd("md5sum {}".format(path_to_file))
    md5 = ret.split()[0]
    return md5

def compare_md5(host,file1,file2):
    """
    compare md5 between two real files
    :param host:
    :param file1:
    :param file2:
    :return:
    """
    file1_md5 = get_md5(host,file1)
    file2_md5 = get_md5(host,file2)
    return True if file1_md5 == file2_md5 else False

def compare_md5_dirs(host,dir1,dir2,file_names):
    result = []
    for file in file_names:
        src1 = dir1+file
        src2 = dir2+file
        result.append(compare_md5(host,src1,src2))
    return result


def _parse_target_line(line):
    if re.match(".*TARGET.*=",line):
        logging.debug(line)
        target_name = line.strip().split("=")[1].strip()
        logging.debug(target_name)
        return target_name

def parse_target(makefile):
    with open(makefile) as f:
        for line in f.readlines():
            target_name = _parse_target_line(line)
            if target_name:
                return target_name

def runnable_files_to_json(files,working_dir):
    if working_dir[-1]!="/":
        working_dir = working_dir + "/"
    filepath = "{}runnable_files.json".format(working_dir)
    with open(filepath,"w") as f:
        f.write(json.dumps(files))

def read_runnable_files(working_dir):
    filepath = "{}runnable_files.json".format(working_dir)
    with open(filepath) as f:
        runnable_files = json.loads(f.read())
    return runnable_files
#
def test_case_18(h1,h2,server_file):
    try:
        # 通过 Makefile 的 Target 找到应该运行的目标文件
        h1.cmd("{} &".format(server_file))
        # 通过 target 判断学生实现的是自己的 TCP 协议栈还是老师提供的 TCP 协议栈
        time.sleep(0.5)
        file_names = ["index.html", "10K.dat", "100K.dat", "1M.dat", "10M.dat"]
        successfully_downloaded_files = download_files(h2, "http://10.0.0.1/", file_names)
        verify_result = compare_md5_dirs(h2, "./", "./www/", successfully_downloaded_files)
        logging.info ("Point {}/{}".format(len([i for i in verify_result if i]), len(file_names)))
    finally:
        h2.cmd("rm -f ./index.html ./100K.dat ./10K.dat ./1M.dat ./10M.dat")

if __name__ == '__main__':
    files = ["123","234"]
    runnable_files_to_json(files,"./")
    another_file = read_runnable_files("./")
    print("another_file:",another_file)