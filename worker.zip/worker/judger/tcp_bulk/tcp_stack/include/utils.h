#ifndef __UTILS_H__
#define __UTILS_H__

#include <sys/time.h>

double time_now();

#endif
