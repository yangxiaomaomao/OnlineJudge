#!/bin/python3
import socket               # 导入 socket 模块
import os

os.system("python3 -m http.server 80 &")